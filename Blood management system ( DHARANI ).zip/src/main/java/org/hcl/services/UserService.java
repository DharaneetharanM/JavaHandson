package org.hcl.services;

import org.hcl.entities.Users;

public interface UserService {
	public boolean insertUser(Users user);
}

