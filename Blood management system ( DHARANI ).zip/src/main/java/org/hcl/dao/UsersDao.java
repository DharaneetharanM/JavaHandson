package org.hcl.dao;
import org.hcl.entities.Users;

public interface UsersDao {
	public boolean insert(Users user);
}

